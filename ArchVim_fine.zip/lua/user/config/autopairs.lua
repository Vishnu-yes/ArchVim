-- =====================
-- 12) AutoPairs (automatic brackets/quotes)
-- =====================
local npairs = require("nvim-autopairs")

npairs.setup({
  check_ts = true,                          -- enable treesitter integration
  ts_config = {
    lua = { "string" },                     -- don't auto-pair inside Lua strings
    javascript = { "template_string" },    -- ignore JS template strings
  },
  disable_filetype = { "TelescopePrompt", "vim", "markdown" }, -- disable for these filetypes
  fast_wrap = {
    map = "<M-e>",                           -- Alt+e to trigger wrap
    chars = { "{", "[", "(", '"', "'" },
    pattern = [=[[%'%"%)%>%]%)%}%,]]=],     -- chars to match for wrapping
    offset = 0,                              -- offset from cursor
    end_key = "$",
    keys = "qwertyuiopzxcvbnmasdfghjkl",    -- keys to jump between pairs
    check_comma = true,
    highlight = "Search",
    highlight_grey = "Comment",
  },
  enable_check_bracket_line = true,         -- avoid pairing brackets if already exists in line
  ignored_next_char = "[%w%.]",             -- ignore letters and dots
})

-- Integrate with nvim-cmp for auto-completion pairing
local cmp_status_ok, cmp = pcall(require, "cmp")
if cmp_status_ok then
  local cmp_autopairs = require("nvim-autopairs.completion.cmp")
  cmp.event:on("confirm_done", cmp_autopairs.on_confirm_done())
end

-- Optional: Add custom rules
local Rule = require("nvim-autopairs.rule")

-- Example: auto-close < and > for HTML
npairs.add_rules({
  Rule("<", ">"):with_pair(function(opts)
    return opts.line:sub(opts.col, opts.col) ~= ">"
  end),
})

-- Example: ignore auto-pair inside comments
npairs.add_rules({
  Rule("{", "}"):with_pair(function(opts)
    local ts = require("nvim-treesitter.ts_utils")
    local node = ts.get_node_at_cursor()
    return not node or node:type() ~= "comment"
  end),
})


