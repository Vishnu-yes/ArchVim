-- ~/.config/nvim/lua/user/UI/trouble.lua
-- Trouble v3 setup with QoL features + Gruvbox tweaks

require("trouble").setup({
  auto_open = false,          -- don't pop up automatically
  auto_close = true,          -- close when list is empty
  warn_no_results = false,
  follow = true,              -- auto-follow cursor
  focus = true,               -- focus Trouble when opened

  keys = {
    ["<cr>"] = "jump_close",  -- Enter jumps + closes Trouble
    ["q"] = "close",          -- q to quit
    ["<esc>"] = "cancel",
    ["r"] = "refresh",        -- refresh diagnostics
    ["<tab>"] = "next",       -- cycle items
    ["<s-tab>"] = "prev",
  },
  wrap = true,
  indent_lines = true,
  multilines = true,
  padding = true,
  icons = {
    indent = {
      top         = "│ ",
      middle      = "├╴",
      last        = "└╴",
      fold_open   = " ",
      fold_closed = " ",
      ws          = "  ",
    },
    kinds = {
      Error = " ",
      Warning = " ",
      Hint = " ",
      Information = " ",
    },
  },
})

-- 🔹 Keymaps (v3 API)
local map = vim.keymap.set

-- Diagnostics
map("n", "<leader>ld", "<cmd>Trouble diagnostics toggle filter.buf=0<CR>", { desc = "Document Diagnostics" })
map("n", "<leader>lw", "<cmd>Trouble diagnostics toggle<CR>", { desc = "Workspace Diagnostics" })

-- Quickfix & References
map("n", "<leader>lq", "<cmd>Trouble qflist toggle<CR>", { desc = "Quickfix List" })
map("n", "<leader>lr", "<cmd>Trouble lsp toggle focus=false win.position=right<CR>", { desc = "LSP References" })

-- 🔹 Navigation (inside Trouble)
map("n", "[q", function() require("trouble").prev({ skip_groups = true, jump = true }) end,
  { desc = "Previous Trouble item" })
map("n", "]q", function() require("trouble").next({ skip_groups = true, jump = true }) end,
  { desc = "Next Trouble item" })

-- 🔹 Optional: Gruvbox-style highlights
vim.api.nvim_set_hl(0, "TroubleNormal", { bg = "#1d2021", fg = "#ebdbb2" })
vim.api.nvim_set_hl(0, "TroubleFoldIcon", { fg = "#fabd2f" })
vim.api.nvim_set_hl(0, "TroubleCount", { fg = "#83a598", bold = true })
vim.api.nvim_set_hl(0, "TroubleError", { fg = "#fb4934" })
vim.api.nvim_set_hl(0, "TroubleWarning", { fg = "#fabd2f" })
vim.api.nvim_set_hl(0, "TroubleHint", { fg = "#b8bb26" })
vim.api.nvim_set_hl(0, "TroubleInformation", { fg = "#83a598" })
