---
Keymaps (DAP Debugging)

<leader>db → Toggle breakpoint

<leader>dB → Set conditional breakpoint (asks for condition)

<leader>dl → Set log point (asks for log message)

<leader>dc → Continue execution

<leader>do → Step over

<leader>di → Step into

<leader>du → Step out

<leader>dr → Open REPL

<leader>de (Normal & Visual) → Evaluate expression


---

Bufferline Navigation Keymaps (Full)

<leader>1 → <leader>9 → Jump to buffer 1–9 safely

Uses listed buffers (nvim_list_bufs)

Switches only if the buffer exists


<A-l> → Next buffer

<A-h> → Previous buffer

Uses a cycle_buffer function to find the current buffer index and move forward/backward


<leader>bb → Pick buffer to switch interactively

Shows a floating selection menu of all listed buffers

Buffer names displayed ([No Name] if empty)

Choosing a buffer switches to it


<leader>bd → Pick buffer to close interactively

Shows a floating selection menu of all listed buffers

Choosing a buffer deletes it (force = true)



Notes:

vim.ui.select() → floating selection menu

vim.api.nvim_set_current_buf(bufnr) → switch buffer

vim.api.nvim_buf_delete(bufnr, { force = true }) → delete buffer


---

Keymaps (Dressing.nvim – Floating UI)

<leader>di → Floating input prompt

Example: Asks "Enter something:" → prints what you typed


<leader>ds → Floating selection menu

Example: Choose from Option 1 / Option 2 / Option 3 → prints choice


<leader>dd → Combined demo: input + select

First asks for input, then lets you pick from options → prints both



---

Noice Keymaps (Quality of Life)

<leader>nh → Open Noice history

<leader>nl → Show last message

<leader>nd → Dismiss current notifications

<leader>nc → Close all notifications (uses notify.dismiss)


Scroll inside LSP popups

<C-f> → Scroll forward 4 lines in LSP popups (Normal, Insert, Select modes)

<C-b> → Scroll backward 4 lines in LSP popups (Normal, Insert, Select modes)


Notes:

If LSP scroll is not possible, <C-f> and <C-b> fallback to normal behavior.

<leader> is your custom leader key (usually Space or \).


---

Focus Keymaps (Window Management)

<leader>ft → Toggle Focus mode (auto-resizes splits)

<leader>fe → Equalise all splits (:wincmd =)

<leader>fm → Maximise current split (temporarily hides others)

<leader>fc → Cycle split layouts (rotates vertical ↔ horizontal)


Notes:

FocusEqualise → runs wincmd = to make all splits equal

FocusMaximise → runs only to focus the current split

FocusSplitCycle → rotates splits unless there’s only one window

<leader> is your custom leader key (usually Space or \)



---


Snacks.nvim Keymaps (Practical)

<leader>nn → Open Snacks Notifications History

<leader>np → Show Snacks Progress (LSP/Tasks)

<leader>ni → Open Snacks Input Prompt

<leader>nb → Open Snacks Buffer Picker


Notes:

All keymaps use the snacks Lua module functions

<leader> is your custom leader key (usually Space or \)



---


## Our Ui is Done Now we will Go for Configs

---
Chad Coder LSP Keymaps & Setup

LSP Keymaps (on_attach)

gd → Go to definition

K → Hover info (symbol under cursor)

gr → List references

<leader>rn → Rename symbol

<leader>ca → Code actions

<leader>f → Format buffer (async)


Diagnostics Keymaps

<leader>la → Show diagnostics for the current line (floating window)

[d → Go to previous diagnostic

]d → Go to next diagnostic

---

Nvim Tree

<leader>e  → Toggle Nvim Tree or File Mamager
<leader>re → Refresh Nvim Tree
<leader>ne → Find File in Nvim Tree

---

Project / Workspace Keymaps

<leader>pw → Open Workspaces

<leader>pa → Add current directory as a Workspace

<leader>pr → Remove a Workspace


Session Management Keymaps

<leader>ps → Save current session

<leader>pl → Load last session

<leader>pd → Delete a session

<leader>ps → Save Session

<leader>pr → Restore Session

Notes:

<leader> is your custom leader key (usually Space or \).

Workspaces and Sessions help organize projects and persist open buffers/windows across Neovim restarts.



---



Telescope Builtin Pickers

<leader>ff → Find files

<leader>fg → Live grep (search text in project)

<leader>fb → List open buffers

<leader>fh → Help tags search


Telescope Extensions

<leader>fe → File browser

<leader>fu → Undo history

<leader>fp → Projects picker

<leader>fz → Zoxide quick directory navigation


Lazy.nvim Plugin Pickers

<leader>fl → Find files in ~/.local/share/nvim/lazy

<leader>lf → Lazy.nvim plugin files (with custom title)

<leader>lg → Lazy.nvim live grep

<leader>lw → Grep current word in Lazy.nvim plugins


Neovim Config Folder

<leader>lc → Find files in ~/.config/nvim


Notes:

<leader> is usually Space or \.

UI-Select is automatically integrated with Telescope and LSP, so no extra mapping is needed.



---

ToggleTerm Keymaps

<C-Space> → Open/Toggle terminal (horizontal, size 15)

Terminal mode (t) buffer-local:

<Esc> → Enter normal mode temporarily (<C-\><C-n>)

<C-q> → Exit terminal buffer (<C-\><C-n>:q<CR>)



Notes:

Terminal automatically snaps back to insert mode if you leave it.

Keymaps are buffer-local in terminal mode.


---


Harpoon 2 Keymaps

<C-e> → Toggle Harpoon menu

<C-a> → Add current file to Harpoon



---

Snipe.nvim Keymaps

<leader>gb → Open Snipe buffer menu

<leader>g1 → Jump to recent buffer 1

<leader>g2 → Jump to recent buffer 2

<leader>g3 → Jump to recent buffer 3

<leader>g4 → Jump to recent buffer 4

<leader>g5 → Jump to recent buffer 5

<leader>gD → Open buffer menu for deletion


Menu Navigation (inside Snipe menu)

<Esc> → Close menu

<CR> → Select buffer

<Tab> → Next buffer in menu

<S-Tab> → Previous buffer in menu

<leader>bd → Delete buffer from menu

---


Todo Comments Keymaps

]t → Jump to next TODO/FIX/HACK/WARN/NOTE comment

[t → Jump to previous TODO/FIX/HACK/WARN/NOTE comment

<leader>xt → List all TODO comments in the quickfix window

<leader>st → Search TODO comments using Telescope


Notes:

To add To Do , just identify how to comment in your existing file's programming Language
For e.g --> Cpp ,       // FIX: Fix this this
Here // Comments out the line so compiler/assembler don't stop or Parser don't Parser
FIX , is a word from Todo plugin usually means to FIX
: , this is used because : is marking what to do without it it is impossible to use Todo

Highlights keywords like TODO:, FIX:, HACK:, WARN:, PERF:, NOTE:

Shows icons in the sign column for each type of comment

Supports ripgrep for fast searching in the project

---


Trouble.nvim Keymaps

Diagnostics

<leader>ld → Toggle document diagnostics

<leader>lw → Toggle workspace diagnostics


Quickfix & LSP References

<leader>lq → Toggle quickfix list

<leader>lr → Toggle LSP references


Navigation inside Trouble

[q → Go to previous Trouble item

]q → Go to next Trouble item


Notes:

Navigation respects groups and jumps directly to the location

Works with LSP and diagnostics seamlessly


---

Moving Lines

Normal mode:

<C-k> → Move current line up

<C-j> → Move current line down


Visual Line mode (selected lines):

<C-k> → Move selection up

<C-j> → Move selection down



Shifting Selection

Keep selection after shifting:

< → Shift left, remain selected

> → Shift right, remain selected


Ctrl-based alternative:

<C-h> → Shift left

<C-l> → Shift right



Range & Buffer Substitution

<leader>rs → Replace in selected range (interactive prompt for start/end lines)

<leader>ra → Replace in whole file

<leader>rs (visual mode) → Replace in selection

<leader>rm → Replace in lines matching a pattern


Notes

Interactive functions _G.SubstituteRange(), _G.SubstituteAll(), _G.SubstituteMatchingLines() handle input prompts.

Visual mappings allow quick replacement without leaving selection.

---
