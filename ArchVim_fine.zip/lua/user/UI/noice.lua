-- ~/.config/nvim/lua/user/UI/noice.lua
local ok, noice = pcall(require, "noice")
if not ok then
  return
end
-- 1️⃣ Define custom highlights for popupmenu
vim.api.nvim_set_hl(0, "NoicePopupNormal", { fg = "#ebdbb2", bg = "#000000" })  -- text + black bg
vim.api.nvim_set_hl(0, "NoicePopupBorder", { fg = "#d75f00", bg = "#000000" })  -- orange border
vim.api.nvim_set_hl(0, "NoicePopupSelected", { fg = "#000000", bg = "#d75f00" }) -- selected item: orange bg, black text

-- 2️⃣ Configure NUI popupmenu
noice.setup({
  popupmenu = {
    enabled = true,
    backend = "nui",   -- modern floating menu
    -- floating window styling
    -- applies custom highlights above
    win_options = {
      winhighlight = "Normal:NoicePopupNormal,FloatBorder:NoicePopupBorder",
    },
    border = {
      style = "rounded",
      padding = { 0, 1 },
    },
    max_width = 60,
    max_height = 12,
    -- highlight selected item
    format_item = function(item)
      return item
    end,
  },
})
noice.setup({
  -- 🔹 Modern floating commandline
  cmdline = {
    enabled = true,
    view = "cmdline_popup",
    format = {
      cmdline = { icon = "", lang = "vim" },
      search_down = { kind = "search", pattern = "^/", icon = " " },
      search_up = { kind = "search", pattern = "^%?", icon = " " },
      filter = { pattern = "^:%s*!", icon = "", lang = "bash" },
    },
    win_options = {
        winhighlight = "Normal:NoiceCmdlineNormal,FloatBorder:NoiceCmdlineBorder",
      },
  },

  messages = {
    enabled = true,
    view = "notify",            -- short messages in notify
    view_error = "notify",
    view_warn = "notify",
    view_history = "messages",  -- full history log
    view_search = "virtualtext",
  },

  popupmenu = {
    enabled = true,
    backend = "nui", -- clean floating menu
  },

  routes = {
    -- Route normal :messages output into notify
    { filter = { event = "msg_show", kind = "" }, view = "notify" },
    { filter = { event = "msg_show", kind = "error" }, view = "notify" },
    { filter = { event = "msg_show", kind = "warn" },  view = "notify" },
  },

  presets = {
    bottom_search = false,      -- disable bottom cmdline, use popup
    command_palette = true,
    long_message_to_split = true,
    inc_rename = true,
    lsp_doc_border = true,
  },

  views = {
    -- 🔹 Yellow modern commandline
    cmdline_popup = {
      border = { style = "rounded", padding = { 0, 0 } },
      position = { row = "30%", col = "50%" },
      size = { width = 60, height = "auto" },
      win_options = {
        winhighlight = "Normal:Normal,FloatBorder:DiagnosticWarn", -- yellow border
      },
    },
    popupmenu = {
      relative = "editor",
      position = { row = "40%", col = "50%" },
      size = { width = 60, height = 10 },
      border = { style = "rounded", padding = { 0, 0 } },
      win_options = {
       winhighlight = "Normal:Normal,FloatBorder:DiagnosticWarn", -- yellow border
      },
    },
  },
})

-- 🔹 Keymaps for Noice (quality of life)
local map = vim.keymap.set
map("n", "<leader>nh", "<cmd>Noice history<CR>", { desc = "Noice History" })
map("n", "<leader>nl", "<cmd>Noice last<CR>", { desc = "Last Message" })
map("n", "<leader>nd", "<cmd>Noice dismiss<CR>", { desc = "Dismiss Notifications" })
vim.keymap.set("n", "<leader>nc", function()
  require("notify").dismiss({ silent = true, pending = true })
end, { desc = "Close all notifications" })

-- 🔹 Scroll inside LSP popups
map({ "n", "i", "s" }, "<C-f>", function()
  if not require("noice.lsp").scroll(4) then return "<C-f>" end
end, { silent = true, expr = true })

map({ "n", "i", "s" }, "<C-b>", function()
  if not require("noice.lsp").scroll(-4) then return "<C-b>" end
end, { silent = true, expr = true })
