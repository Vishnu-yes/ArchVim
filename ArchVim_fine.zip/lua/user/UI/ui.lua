-- UI Elementts Fall Here
--Add all UI things etc here.
-- =====================
-- Basic editor settings
-- =====================

function _G.MyTabline()
    local current_tab = vim.fn.tabpagenr()
    local total_tabs = vim.fn.tabpagenr('$')
    -- Get filename of current tab
    local win = vim.fn.tabpagewinnr(current_tab)
    local buf = vim.fn.tabpagebuflist(current_tab)[win]
    local name = vim.fn.fnamemodify(vim.fn.bufname(buf), ":t")
    if name == "" then
        name = "[No Name]"
    end

    -- Indicator: if there are more tabs
    local indicator = ""
    if total_tabs > current_tab then
        indicator = string.format("[%d m]", current_tab)
    else
        indicator = string.format("[%d]", current_tab)
    end

    -- Return with highlights
    return "%#TabLineSel# " .. name .. " ⨯   " .. indicator .. " ⨯ %#TabLineFill#"
end

-- ##########################
-- Colorscheme control
-- ##########################

-- Set background preference
vim.o.background = "dark"

-- Load Gruvbox (ellisonleao/gruvbox.nvim)
-- ##########################
-- Colorscheme control
-- ##########################
-- lua/config/colorscheme.lua

-- Set background preference
vim.o.background = "dark"

-- Load Gruvbox (ellisonleao/gruvbox.nvim)
require("gruvbox").setup({
  --terminal_colors = true,  -- apply Gruvbox colors to :terminal
  undercurl = true,
  underline = true,
  bold = true,
  italic = {
    strings = false,
    comments = false,
    operators = false,
    folds = true,
  },
  strikethrough = true,
  invert_selection = false,
  invert_signs = false,
  invert_tabline = false,
  invert_intend_guides = false,
  inverse = false, -- invert background for search, diffs, statuslines
  contrast = "hard", -- options: "hard", "soft", ""
  palette_overrides = {},
  overrides = {
    -- 🔹 Telescope
    TelescopePromptNormal  = { bg = "#32302f" },
    TelescopeResultsNormal = { bg = "#282828" },
    TelescopePreviewNormal = { bg = "#1d2021" },

    -- 🔹 Gutter fix (no cursorline color bleed)
    SignColumn   = { bg = "#1d2021" },
    LineNr       = { bg = "#1d2021", fg = "#7c6f64" },
    CursorLineNr = { bg = "#1d2021", fg = "#fabd2f", bold = true },
    FoldColumn   = { bg = "#1d2021", fg = "#928374" },

    --This thing is very Important!
    -- 🔹 Diagnostics signs → fg only (no bg)
    DiagnosticSignError = { fg = "#fb4934", bg = "#1d2021" },
    DiagnosticSignWarn  = { fg = "#fe8019", bg = "#1d2021" },
    DiagnosticSignInfo  = { fg = "#83a598", bg = "#1d2021" },
    DiagnosticSignHint  = { fg = "#b8bb26", bg = "#1d2021" },

    --Snacks flow
    -- 🔹 Snacks floating input / command-line
    FloatBorder = { fg = "#fabd2f", bg = "#1d2021" },  -- yellow border
    NormalFloat = { fg = "#fb4934", bg = "#1d2021" },  -- red text inside, dark bg
    Title       = { fg = "#fb4934", bg = "#1d2021", bold = true }, -- title/header in red
    Question    = { fg = "#fb4934", bg = "#1d2021" },  -- ":" prompt in red
  },
  dim_inactive = false,
  transparent_mode = false, -- set to true if you want transparent bg
})

-- Apply colorscheme
vim.cmd("colorscheme gruvbox")

-- Optional: remove ~ from empty lines
vim.opt.fillchars:append { eob = " " }
-- -----------------------------
-- Disable Vim/Neovim Animations
-- -----------------------------

-- Disable redrawing while executing macros, registers, or commands
vim.opt.lazyredraw = true
-- Disable blinking cursor and GUI animations (depends on terminal)
--vim.opti.guicursor = "" 

-- Make scrolling instant
vim.opt.scrolloff = 0
vim.opt.sidescrolloff = 0

-- Disable incremental search animation
vim.opt.incsearch = false
vim.opt.hlsearch = false


-- Disable mode display, command preview, etc.
--vim.opt.showmode = false
--vim.opt.showcmd = false

-- Set redraw time very low (no redraw delays)
--vim.opt.redrawtime = 100

-- Optional: Disable visual bells / flashes
--vim.opt.visualbell = true
--vim.opt.errorbells = false
-- Enable highlighting the current line
--vim.opt.cursorline = true

-- Force a better color for the cursor line
vim.api.nvim_set_hl(0, "CursorLine", { bg = "#3c3836" })  -- a slightly darker gray-brown

--Visual Mode 
--vim.api.nvim_set_hl(0, "Visual", { bg = "#3c3836", fg = nil })  -- old suggestion

-- Visual Block 
--vim.api.nvim_set_hl(0, "VisualNOS", { bg = "#3c3836", fg = nil })


-- =========================
-- Universal Counter Styling
-- =========================
-- Pick your desired colors
local counter_fg = "#FFFFFF"  -- bright white
local counter_bg = nil        -- transparent (inherit float bg)
local counter_style = { fg = counter_fg, bg = counter_bg, bold = true }

-- Apply overrides for all possible backends
local groups = {
  "FloatTitle",            -- dressing.nvim / nvim core float title
  "FloatTitleSeparator",   -- some UIs split title vs separator
  "TelescopePromptCounter",-- telescope prompt counter
  "TelescopeResultsTitle", -- telescope results title
  "TelescopePreviewTitle", -- telescope preview title
  "FzfLuaPromptCounter",   -- fzf-lua prompt counter
  "FzfLuaTitle",           -- fzf-lua floating title
  -- Dressing.nvim
  "DressingPromptCounter",
  "DressingPromptTitle",
  "DressingPromptBorder",
  "DressingPromptNormal",
}

for _, group in ipairs(groups) do
  vim.api.nvim_set_hl(0, group, counter_style)
end
