---Diagnostic Signs


vim.diagnostic.config({
    signs =
    {
        text =
        {
            [vim.diagnostic.severity.ERROR] = "",
            [vim.diagnostic.severity.WARN] = "",
            [vim.diagnostic.severity.HINT] = "",
            [vim.diagnostic.severity.INFO] = "",
        },
        numhl =
        {
            [vim.diagnostic.severity.ERROR] =
            "DiagnosticSignError",
            [vim.diagnostic.severity.WARN] = "DiagnosticSignWarn",
            [vim.diagnostic.severity.HINT] = "DiagnosticSignHint",
            [vim.diagnostic.severity.INFO] = "DiagnosticSignInfo",
        },
    },
})
-- Force Neovim background to your color
vim.opt.background = "dark"  -- optional but recommended
local bg_color = "#282828"   -- Gruvbox dark default

-- Override Normal highlight (main UI)
vim.api.nvim_set_hl(0, "Normal", { bg = bg_color, fg = "#ebdbb2" }) -- fg is optional
vim.api.nvim_set_hl(0, "NormalNC", { bg = bg_color }) -- non-current windows
vim.api.nvim_set_hl(0, "NormalFloat", { bg = bg_color }) -- floating windows
vim.api.nvim_set_hl(0, "VertSplit", { bg = bg_color }) -- vertical splits
vim.api.nvim_set_hl(0, "StatusLine", { bg = bg_color })
vim.api.nvim_set_hl(0, "StatusLineNC", { bg = bg_color })
