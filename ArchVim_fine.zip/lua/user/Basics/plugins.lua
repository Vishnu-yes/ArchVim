-- Your Plugins must be added here.
-- =====================
-- (1) Bootstrap lazy.nvim
-- =====================
local lazypath = vim.fn.stdpath("data") .. "/lazy/lazy.nvim"
if not vim.loop.fs_stat(lazypath) then
    vim.fn.system({
        "git",
        "clone",
        "--filter=blob:none",
        "https://github.com/folke/lazy.nvim.git",
        lazypath, })
end
vim.opt.rtp:prepend(lazypath)

-- =====================
-- Plugins (lazy.nvim)
-- =====================
require("lazy").setup({
    -- core
    { "nvim-lua/plenary.nvim",               lazy = true },
    { "nvim-tree/nvim-web-devicons",         lazy = true },

    -- themes (lots of great defaults)
    { "ellisonleao/gruvbox.nvim",            priority = 1000 },
    --{ "projekt0n/github-nvim-theme",         name = "github-theme",                 priority = 999 },
    { "lunarvim/colorschemes" }, -- LunarVim’s default colorscheme collection
    { "folke/tokyonight.nvim" },
    { "catppuccin/nvim",                     name = "catppuccin" },
    { "EdenEast/nightfox.nvim" },
    { "shaunsingh/nord.nvim" },
    { "Mofiqul/vscode.nvim" },
    { "navarasu/onedark.nvim" },
    { "rebelot/kanagawa.nvim" },
    { "chriskempson/vim-tomorrow-theme" },

    -- UI
    { "lewis6991/gitsigns.nvim",             event = { "BufReadPre", "BufNewFile" } },
    { "lukas-reineke/indent-blankline.nvim", main = "ibl",                          event = { "BufReadPost", "BufNewFile" } },
    {
        "akinsho/bufferline.nvim",
        version = "*",
        dependencies = "nvim-tree/nvim-web-devicons",
        event = "VeryLazy",
    },
    {
        "nvim-tree/nvim-tree.lua",
        dependencies = { "nvim-tree/nvim-web-devicons" },
    },

    --completion
    {
        "hrsh7th/nvim-cmp",
        dependencies = {
            "hrsh7th/cmp-nvim-lsp",
            "hrsh7th/cmp-buffer",
            "hrsh7th/cmp-path",
            "L3MON4D3/LuaSnip",
            "saadparwaiz1/cmp_luasnip",
        },
    },

    -- autopairs
    { "windwp/nvim-autopairs",       event = "InsertEnter" },
    -- Your Plugins here

    -- ==== Formatter (Not Good for Humans)
    --{ "stevearc/conform.nvim",       event = "BufWritePre" },

    -- ===== Statusline
    { "nvim-lualine/lualine.nvim",   dependencies = { "nvim-tree/nvim-web-devicons" } },

    -- ===== Dap + UI
    { "mfussenegger/nvim-dap" },
    { "rcarriga/nvim-dap-ui",        dependencies = { "mfussenegger/nvim-dap" } },
    { "williamboman/mason.nvim",     enabled = true }, -- keep off since you don’t use mason
    {
    "mason-org/mason.nvim",
    opts = {}
},
    { "nvim-neotest/nvim-nio" },                        -- dependency

    -- ==== Sessions & workspace
    { "rmagatti/auto-session" },
    { "natecraddock/workspaces.nvim" },

    -- ====== Notify
    { "rcarriga/nvim-notify" },

    -- Dashboard (startup screen)
    -- { "nvimdev/dashboard-nvim", event = "VimEnter" },
    -- alpha.nvim (dashboard)
    {
        "goolord/alpha-nvim",
        event = "VimEnter",
        dependencies = { "nvim-tree/nvim-web-devicons" },
        config = function()
        end,
    },
    -- Project.nvim (detect project roots)
    { "ahmedkhalf/project.nvim" },

    -- Trouble.nvim (diagnostics / references UI)
    { "folke/trouble.nvim",     dependencies = { "nvim-tree/nvim-web-devicons" } },
    -- ~/.config/nvim/lua/user/Basics/plugins.lua
    {
      "echasnovski/mini.icons",
      version = false, -- always use latest
      lazy = true,
      config = function()
        require("mini.icons").setup()
      end,
    },

    -- Harpoon (quick file navigation)
    {
        "ThePrimeagen/harpoon",
        branch = "harpoon2",
        dependencies = { "nvim-lua/plenary.nvim" },
    },

    -- Refactoring
    {
        "ThePrimeagen/refactoring.nvim",
        dependencies = { "nvim-lua/plenary.nvim", "nvim-treesitter/nvim-treesitter" },
    },

    -- Todo Comments
    { "folke/todo-comments.nvim", dependencies = { "nvim-lua/plenary.nvim" } },

    -- Neoscroll (smooth scrolling)
    { "karb94/neoscroll.nvim",    config = true },



    -- =====================
    -- Telescope + Extensions
    -- =====================
    {
        "nvim-telescope/telescope.nvim",
        tag = "0.1.5",
        dependencies = {
            "nvim-lua/plenary.nvim",
            "nvim-tree/nvim-web-devicons",

            -- 🔹 Performance
            { "nvim-telescope/telescope-fzf-native.nvim", build = "make" },

            -- 🔹 Extra pickers
            "nvim-telescope/telescope-file-browser.nvim",
            "nvim-telescope/telescope-project.nvim",
            "jvgrootveld/telescope-zoxide",
            "debugloop/telescope-undo.nvim",

            -- 🔹 UI
            "nvim-telescope/telescope-ui-select.nvim",
        },
    },




    -- treesitter
    { "nvim-treesitter/nvim-treesitter", build = ":TSUpdate" },

    -- LSP config
    { "neovim/nvim-lspconfig",           event = { "BufReadPre", "BufNewFile" }, dependencies = { "hrsh7th/cmp-nvim-lsp" } },

    -- snippets
    { "L3MON4D3/LuaSnip",                lazy = true },
    { "honza/vim-snippets",              lazy = true },

    -- terminal
    { "akinsho/toggleterm.nvim",         version = "*" },

    -- ====================
    --  Add More From here
    -- ====================
    -- Command Cheat Code with Dependency which-key.nvim
    { "mrjones2014/legendary.nvim" },
    {
        "folke/which-key.nvim",
        event = "VeryLazy",
        config = function()
            require("which-key").setup()
        end,
    },

    --Better UI
    {
        "folke/snacks.nvim",
        event = "VeryLazy",
        opts = {
            input = { enabled = true },   -- override vim.ui.input
            select = { enabled = true },  -- override vim.ui.select
            notify = { enabled = true },  -- override vim.notify
            picker = { enabled = true },  -- simple picker UI
            progress = { enabled = true }, -- LSP/progress spinner
            statuscolumn = { enabled = true } -- nicer statuscolumn
        },
    },
    ---Dap UI dependencies
    -- in your plugins.lua
    {
        "mfussenegger/nvim-dap",
        dependencies = {
            "rcarriga/nvim-dap-ui",
            "theHamsta/nvim-dap-virtual-text", -- <--- add this
        },
        config = function()
            require("user.UI.DAP_UI") -- or your dap config
        end,
    },
-- =====================
-- Better UI plugins (organized)
-- =====================
    {
      -- Better vim.ui.select / vim.ui.input
      { "stevearc/dressing.nvim" },

      -- Modern notifications, cmdline, messages
      {
        "folke/noice.nvim",
        dependencies = { "MunifTanjim/nui.nvim" },
      },

      -- Auto-resize & manage splits (modern replacement for windows.nvim)
      { "beauwilliams/focus.nvim" },

      -- Fuzzy finder
      { "nvim-telescope/telescope.nvim", dependencies = { "nvim-lua/plenary.nvim" } },

      -- File explorer
      {
        "nvim-neo-tree/neo-tree.nvim",
        branch = "v3.x",
        dependencies = { "nvim-lua/plenary.nvim" },
      },

      -- Quick buffer jump
      { "leath-dub/snipe.nvim" },
    },


-- ##################
-- Inbuilt here
-- ##################

-- #####################################
-- Multicursor Plugin 
-- You can easily move lines up or down 
-- Via c-j c-k in normal mode
-- #####################################   

    {
        "onsails/lspkind-nvim",
        config = function()
            require('lspkind').init()
        end
    }

}) ---- Plugins Stop.
