return {
  "folke/which-key.nvim",
  event = "VeryLazy",
  config = function()
    local wk = require("which-key")

    -- Setup with proper borders
    wk.setup({
      plugins = {
        marks = true,
        registers = true,
        spelling = { enabled = true, suggestions = 20 },
      },
      win = {
        border = "rounded", -- rounded, single, double, shadow, none
        padding = { 1, 2 }, -- extra window padding [top/bottom, right/left]
        title = true,
        title_pos = "center",
        zindex = 1000,
      },
      layout = {
        width = { min = 20, max = 50 },
        height = { min = 4, max = 25 },
        spacing = 3,
        align = "left",
      },
      icons = {
        breadcrumb = "»",
        separator = "➜",
        group = "+",
      },
      show_help = true,
      show_keys = true,
    })

    -- Leader key mappings
    wk.add({
      { "<leader>f", group = "Find" },
      { "<leader>ff", "<cmd>Telescope find_files<cr>", desc = "Files" },
      { "<leader>fg", "<cmd>Telescope live_grep<cr>", desc = "Grep" },
      { "<leader>fb", "<cmd>Telescope buffers<cr>", desc = "Buffers" },
      { "<leader>fh", "<cmd>Telescope help_tags<cr>", desc = "Help" },
      
      { "<leader>c", group = "Config" },
      { "<leader>cr", function()
          dofile(vim.fn.stdpath("config") .. "/init.lua")
          vim.notify("Config reloaded!", vim.log.levels.INFO)
        end, desc = "Reload config" },
      
      { "<leader>w", "<cmd>w<cr>", desc = "Save file" },
    })
  end,
}
