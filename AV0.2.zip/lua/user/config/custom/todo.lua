-- Todo Comments
require("todo-comments").setup({
    signs = true, -- show icons in the sign column
    keywords = {
        FIX = { icon = " ", color = "error", alt = { "FIXME", "BUG", "ISSUE" } },
        TODO = { icon = " ", color = "info" },
        HACK = { icon = " ", color = "warning" },
        WARN = { icon = " ", color = "warning", alt = { "WARNING", "XXX" } },
        PERF = { icon = " ", color = "hint", alt = { "OPTIMIZE" } },
        NOTE = { icon = " ", color = "hint", alt = { "INFO" } },
    },
    highlight = {
        before = "", -- no extra highlight before keyword
        keyword = "wide", -- highlight the keyword and following text
        after = "fg", -- highlight text after keyword
        pattern = [[.*<(KEYWORDS)\s*:]], -- match "TODO:", "FIX:", etc.
    },
    search = {
        command = "rg",
        args = { "--color=never", "--no-heading", "--with-filename", "--line-number", "--column" },
        pattern = [[\b(KEYWORDS):]], -- ripgrep pattern
    },
})

-- Keymaps
local map = vim.keymap.set
map("n", "]t", function() require("todo-comments").jump_next() end, { desc = "Next todo comment" })
map("n", "[t", function() require("todo-comments").jump_prev() end, { desc = "Previous todo comment" })
map("n", "<leader>xt", ":TodoQuickFix<CR>", { desc = "List todos in quickfix" })
map("n", "<leader>st", ":TodoTelescope<CR>", { desc = "Search todos with Telescope" })
