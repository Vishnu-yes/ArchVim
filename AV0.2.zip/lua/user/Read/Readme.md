ArchVim A smooth Distro

Pics:






Why Download ? 
• If you ever want a free better , smooth , Distro 
• If you want fancy and Cool Plugins at even on Low end Devices
• If you are bored of Vscode 
• If your Theming sucks or Wants a eye love Theming
• If you love Gruvbox themes Harder
• If you wants to Modify the Distro Easily
• If you love simplicity + full power
• If you are a Coder


How to Download ?

• Make sure to Backup your configs.
```bash 
cp -r  ~/.config/nvim ~/Backups
```

• Clone the Repo (Don't worry it is Lightweight)
```bash 
gitclone 
```


