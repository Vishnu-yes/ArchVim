local lualine = require("lualine")

-- 🔹 Helper: Active LSP client(s)
local function lsp_client()
  local clients = vim.lsp.get_clients()
  local names = {}
  for _, client in ipairs(clients) do
    if vim.lsp.buf_is_attached(0, client.id) then
      table.insert(names, client.name)
    end
  end
  if #names == 0 then
    return "No LSP"
  end
  return " " .. table.concat(names, ", ")
end

-- Unified color
local color_bg = { fg = "#ffffff", bg = "#1d2021", gui = "bold" }

lualine.setup({
  options = {
    theme = "auto",
    globalstatus = true,
    icons_enabled = true,
    section_separators = { left = "", right = "" },
    component_separators = { left = "", right = "" },
    refresh = {
      statusline = 100,
      tabline = 100,
      winbar = 100,
    },
  },
  sections = {
    lualine_a = { { "mode", icon = "", color = color_bg, separator = { left = "", right = "" } } },
    lualine_b = {
      { "branch", icon = "", color = color_bg, separator = { left = "", right = "" } },
      { "diff", symbols = { added = " ", modified = " ", removed = " " }, color = color_bg, separator = { left = "", right = "" } },
      { "diagnostics",
        sources = { "nvim_diagnostic" },
        symbols = { error = " ", warn = " ", info = " ", hint = " " },
        color = color_bg,
        separator = { left = "", right = "" },
      },
    },
   lualine_c = {
  {
    "filename",
    path = 1,
    symbols = { modified = " ", readonly = " " },
    color = color_bg,
    separator = { left = "", right = "" },
  },
},
lualine_x = {
  { lsp_client, color = color_bg, separator = { left = "", right = "" } },
  { "encoding", color = color_bg, separator = { left = "", right = "" } },
  { "fileformat", color = color_bg, separator = { left = "", right = "" } },
  { "filetype", color = color_bg, separator = { left = "", right = "" } },
},
    lualine_y = { { "progress", separator = " ", padding = { left = 1, right = 1 }, color = color_bg } },
    lualine_z = { { "location", color = color_bg } },
  },
  inactive_sections = {
    lualine_a = {},
    lualine_b = {},
    lualine_c = { { "filename", color = color_bg } },
    lualine_x = { { "location", color = color_bg } },
    lualine_y = {},
    lualine_z = {},
  },
})

-- Reduce redraw flashes
vim.cmd([[
  augroup LazyRedraw
    autocmd!
    autocmd CmdlineEnter * set lazyredraw
    autocmd CmdlineLeave * set nolazyredraw
  augroup END
]])
