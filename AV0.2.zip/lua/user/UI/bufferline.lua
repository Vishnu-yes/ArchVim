-- =====================
-- Bufferline (Modern VSCode Look)
-- =====================
local bufferline = require("bufferline")

bufferline.setup({
  options = {
    numbers = "ordinal",                     -- show buffer numbers
    indicator = { icon = "▌", style = "icon" }, -- VSCode-style left indicator
    buffer_close_icon = "⨯",                 -- per-buffer close icon
    modified_icon = "●",                     -- modified buffer dot
    close_icon = "",                          -- hide global close
    show_buffer_icons = true,                 -- show filetype icons
    show_buffer_close_icons = true,           -- per-buffer close
    show_close_icon = false,                  -- hide global close
    enforce_regular_tabs = false,             -- flexible width
    always_show_bufferline = true,
    tab_size = 30,                             -- wider, VSCode-like
    max_name_length = 25,                      -- truncate long names
    max_prefix_length = 15,
    separator_style = "thin",
    offsets = {
      { filetype = "NvimTree", text = "Explorer", text_align = "left" },
    },
    color_icons = true,
    persist_buffer_sort = true,
    diagnostics = "nvim_lsp",
    hover = {
      enabled = true,
      delay = 150,
      reveal = { "close" },
    },
    view = "multiwindow",
    right_mouse_command = "bdelete! %d",
    left_mouse_command = "buffer %d",
    middle_mouse_command = nil,
  },

  highlights = {
    fill = { guifg = "#ABB2BF", guibg = "#1E1E2E" },
    background = { guifg = "#5C6370", guibg = "#1E1E2E" },
    buffer_visible = { guifg = "#DCDCDC", guibg = "#2E2E3A" },
    buffer_selected = { guifg = "#FFFFFF", guibg = "#007ACC", gui = "bold" },
    close_button = { guifg = "#FF5C57", guibg = "#2E2E3A" },
    close_button_visible = { guifg = "#FF5C57", guibg = "#2E2E3A" },
    close_button_selected = { guifg = "#FFFFFF", guibg = "#007ACC" },
    modified = { guifg = "#E5C07B", guibg = "#2E2E3A" },
    modified_selected = { guifg = "#FFFFFF", guibg = "#007ACC" },
    separator = { guifg = "#2C2C34", guibg = "#2E2E3A" },
    separator_selected = { guifg = "#007ACC", guibg = "#2E2E3A" },
    indicator_selected = { guifg = "#FFFFFF", guibg = "#007ACC" },
    -- diagnostics
    diagnostic = { guifg = "#FF5C57" },
    diagnostic_visible = { guifg = "#FFAA00" },
    diagnostic_selected = { guifg = "#FFFFFF" },
  },
})

-- =====================
-- Keymaps for Bufferline navigation
-- =====================
local map = vim.keymap.set
local opts = { noremap = true, silent = true }

-- Jump to buffer 1-9 safely using nvim_list_bufs and set_current_buf
for i = 1, 9 do
  map("n", "<leader>" .. i, function()
    local buffers = vim.fn.getbufinfo({buflisted = 1})  -- list of open buffers
    if buffers[i] then
      vim.api.nvim_set_current_buf(buffers[i].bufnr)    -- switch to buffer safely
    end
  end, opts)
end


-- cycle to next/prev listed buffer
local function cycle_buffer(next)
  local buffers = vim.fn.getbufinfo({ buflisted = 1 })
  if #buffers == 0 then return end

  local current = vim.api.nvim_get_current_buf()
  local idx = 1
  for i, b in ipairs(buffers) do
    if b.bufnr == current then
      idx = i
      break
    end
  end

  local target = next and (idx % #buffers + 1) or ((idx - 2) % #buffers + 1)
  vim.api.nvim_set_current_buf(buffers[target].bufnr)
end

-- Previos and Next Buffer toggle
map("n", "<A-l>", function() cycle_buffer(true) end, opts)
map("n", "<A-h>", function() cycle_buffer(false) end, opts)

-- pick buffer to switch
map("n", "<leader>bb", function()
  local buffers = vim.fn.getbufinfo({ buflisted = 1 })
  local items = {}
  for _, b in ipairs(buffers) do
    table.insert(items, { text = b.name ~= "" and vim.fn.fnamemodify(b.name, ":t") or "[No Name]", bufnr = b.bufnr })
  end

  vim.ui.select(items, {
    prompt = "Pick a buffer:",
    format_item = function(item) return item.text end,
  }, function(choice)
    if choice then vim.api.nvim_set_current_buf(choice.bufnr) end
  end)
end, opts)

-- pick buffer to close
map("n", "<leader>bd", function()
  local buffers = vim.fn.getbufinfo({ buflisted = 1 })
  local items = {}
  for _, b in ipairs(buffers) do
    table.insert(items, { text = b.name ~= "" and vim.fn.fnamemodify(b.name, ":t") or "[No Name]", bufnr = b.bufnr })
  end

  vim.ui.select(items, {
    prompt = "Close buffer:",
    format_item = function(item) return item.text end,
  }, function(choice)
    if choice then vim.api.nvim_buf_delete(choice.bufnr, { force = true }) end
  end)
end, opts)
