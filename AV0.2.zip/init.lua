-- ============================
-- Neovim Init File
-- ============================
local function safe_require(module)
    local ok, result = pcall(require, module)
    if not ok then
        vim.notify("Failed to load " .. module .. "\n" .. result, vim.log.levels.ERROR)
        return nil
    end
    return result
end
-- ----------------------------
-- 1. Basic Settings
-- ----------------------------
safe_require("user.Basics.env")        -- environment variables
safe_require("user.Basics.options")    -- vim options
safe_require("user.Basics.mappings")   -- keymaps
safe_require("user.Basics.autoreload") -- autoreload config
safe_require("user.Basics.plugins")    -- plugin setup with lazy.nvim
safe_require("user.Basics.utilities")  -- helper function
-- ----------------------------
--  2. UI Enhancements (Overridden)
-- ----------------------------
safe_require("user.UI.dashboard")
safe_require("user.UI.DAP_UI")
safe_require("user.UI.diagonasticsigns")
safe_require("user.UI.IBL")
safe_require("user.UI.bufferline")
safe_require("user.UI.gitsigns")
safe_require("user.UI.statusline")
--safe_require("user.UI.snacks") --important plugin for notifications etc

-- ----------------------------
-- 3. Plugin Configurations
-- ----------------------------
safe_require("user.config.lsp")        -- LSP servers
safe_require("user.config.cmp")        -- completion
safe_require("user.config.autopairs")  -- autopairs
safe_require("user.config.formattor")  -- formatter
safe_require("user.config.notify")     -- notifications
safe_require("user.config.nvimtree")   -- file explorer
safe_require("user.config.telescope")  -- telescope
safe_require("user.config.toggleterm") -- terminal
safe_require("user.config.workspace")  -- workspace mgmt
safe_require("user.config.sessions")   -- session mgmt

-- ----------------------------
-- 4. Custom Plugin Configs
-- ----------------------------
safe_require("user.config.custom.trouble")
safe_require("user.config.custom.harpoon")
safe_require("user.config.custom.snipe")
safe_require("user.config.custom.todo")
safe_require("user.config.custom.sessions") -- if different from config/sessions.lua
safe_require("user.config.custom.legendarynvim")
safe_require("user.config.custom.multiselect")
--safe_require("user.config.custom.multiselect")

-- --------------------------
-- Over Ride Plugins here
-- --------------------------
safe_require("user.UI.dressing")
safe_require("user.UI.noice")
safe_require("user.UI.windows")

-- ----------------------------------
-- Inbuilt Plugins for Better Life
-- ----------------------------------

safe_require("user.Inbuilt.luanmulti")
safe_require("user.Inbuilt.comment")
-- -----------------------------
-- This is Reserved
-- -----------------------------
safe_require("user.UI.snacks") --important plugin for notifications etc
safe_require("user.UI.theme")  --- Place it at last here for better ui 
safe_require("user.UI.colors")
