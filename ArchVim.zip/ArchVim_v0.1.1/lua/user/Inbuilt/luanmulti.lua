-- Full Multi-cursor implementation for Neovim (VSCode-like)
-- This provides a complete multi-cursor experience similar to VSCode

local M = {}
M.cursors = {}
M.active = false
M.namespace = vim.api.nvim_create_namespace('multicursor')

-- Clear all virtual cursors
local function clear_cursors()
  vim.api.nvim_buf_clear_namespace(0, M.namespace, 0, -1)
  M.cursors = {}
  M.active = false
end

-- Draw virtual cursors
local function draw_cursors()
  vim.api.nvim_buf_clear_namespace(0, M.namespace, 0, -1)
  for _, pos in ipairs(M.cursors) do
    local line, col = pos[1] - 1, pos[2]
    vim.api.nvim_buf_set_extmark(0, M.namespace, line, col, {
      virt_text = {{'│', 'Cursor'}},
      virt_text_pos = 'overlay',
      hl_mode = 'combine',
    })
  end
end

-- Add cursor at current position (manual placement)
function M.add_cursor_here()
  local pos = vim.api.nvim_win_get_cursor(0)
  -- Check if cursor already exists at this position
  for _, existing in ipairs(M.cursors) do
    if existing[1] == pos[1] and existing[2] == pos[2] then
      print("Cursor already exists here")
      return
    end
  end
  table.insert(M.cursors, pos)
  M.active = true
  draw_cursors()
  print(string.format("Cursors: %d", #M.cursors))
end

-- Add cursor at word under cursor (NEW FUNCTION)
function M.add_cursor_at_word()
  local pos = vim.api.nvim_win_get_cursor(0)
  local word = vim.fn.expand('<cword>')
  
  if word == '' then
    print("No word under cursor")
    return
  end
  
  -- Move to start of word
  vim.cmd('normal! b')
  local word_start = vim.api.nvim_win_get_cursor(0)
  
  -- Check if cursor already exists
  for _, existing in ipairs(M.cursors) do
    if existing[1] == word_start[1] and existing[2] == word_start[2] then
      print("Cursor already exists on this word")
      return
    end
  end
  
  table.insert(M.cursors, word_start)
  M.active = true
  draw_cursors()
  print(string.format("Added cursor at '%s' - Total cursors: %d", word, #M.cursors))
end

-- Add cursor at each match of word under cursor
function M.select_all_word()
  local word = vim.fn.expand('<cword>')
  if word == '' then
    print("No word under cursor")
    return
  end
  
  clear_cursors()
  local lines = vim.api.nvim_buf_get_lines(0, 0, -1, false)
  local pattern = '\\<' .. vim.pesc(word) .. '\\>'
  
  for line_num, line_text in ipairs(lines) do
    local col = 1
    while true do
      local start_col, end_col = vim.fn.match(line_text, pattern, col - 1), vim.fn.matchend(line_text, pattern, col - 1)
      if start_col == -1 then break end
      table.insert(M.cursors, {line_num, start_col})
      col = end_col + 1
    end
  end
  
  if #M.cursors > 0 then
    M.active = true
    draw_cursors()
    print(string.format("Selected %d occurrences of '%s'", #M.cursors, word))
  else
    print(string.format("No matches found for '%s'", word))
  end
end

-- Add cursor at next match of word under cursor
function M.select_next_word()
  local word = vim.fn.expand('<cword>')
  if word == '' then
    print("No word under cursor")
    return
  end
  
  local current_pos = vim.api.nvim_win_get_cursor(0)
  local lines = vim.api.nvim_buf_get_lines(0, 0, -1, false)
  local pattern = '\\<' .. vim.pesc(word) .. '\\>'
  
  -- Search from current position forward
  for line_num = current_pos[1], #lines do
    local start_col = (line_num == current_pos[1]) and current_pos[2] + 1 or 0
    local match_col = vim.fn.match(lines[line_num], pattern, start_col)
    
    if match_col ~= -1 then
      table.insert(M.cursors, {line_num, match_col})
      vim.api.nvim_win_set_cursor(0, {line_num, match_col})
      M.active = true
      draw_cursors()
      print(string.format("Cursors: %d", #M.cursors))
      return
    end
  end
  
  -- Wrap around to beginning if not found
  for line_num = 1, current_pos[1] - 1 do
    local match_col = vim.fn.match(lines[line_num], pattern, 0)
    if match_col ~= -1 then
      table.insert(M.cursors, {line_num, match_col})
      vim.api.nvim_win_set_cursor(0, {line_num, match_col})
      M.active = true
      draw_cursors()
      print(string.format("Cursors: %d (wrapped)", #M.cursors))
      return
    end
  end
  
  print(string.format("No more matches for '%s'", word))
end

-- Skip current and select next occurrence
function M.skip_next_word()
  local word = vim.fn.expand('<cword>')
  if word == '' then return end
  
  local current_pos = vim.api.nvim_win_get_cursor(0)
  local lines = vim.api.nvim_buf_get_lines(0, 0, -1, false)
  local pattern = '\\<' .. vim.pesc(word) .. '\\>'
  
  -- Search from word end position forward
  local word_end = current_pos[2] + #word
  for line_num = current_pos[1], #lines do
    local start_col = (line_num == current_pos[1]) and word_end or 0
    local match_col = vim.fn.match(lines[line_num], pattern, start_col)
    
    if match_col ~= -1 then
      vim.api.nvim_win_set_cursor(0, {line_num, match_col})
      print("Skipped to next occurrence")
      return
    end
  end
  
  print("No more matches")
end

-- Add cursors to visual selection (FIXED VERSION)
function M.add_cursors_to_selection()
  local mode = vim.fn.mode()
  local start_line = vim.fn.line("'<")
  local end_line = vim.fn.line("'>")
  local start_col = vim.fn.col("'<") - 1
  local end_col = vim.fn.col("'>") - 1
  
  clear_cursors()
  
  -- Handle different visual modes
  if mode == 'V' or mode == 'v' or mode == '\22' then -- V, v, or Ctrl-v
    -- Always add cursor to each line in the selection
    for line = start_line, end_line do
      -- Get the line content to find first non-whitespace if needed
      local line_text = vim.api.nvim_buf_get_lines(0, line - 1, line, false)[1] or ""
      local col = start_col
      
      -- For visual line mode, use first non-blank character
      if mode == 'V' then
        col = vim.fn.match(line_text, '\\S')
        if col == -1 then col = 0 end
      end
      
      table.insert(M.cursors, {line, col})
    end
    
    M.active = true
    draw_cursors()
    vim.api.nvim_feedkeys(vim.api.nvim_replace_termcodes('<Esc>', true, false, true), 'n', false)
    print(string.format("Added %d cursors (lines %d-%d)", #M.cursors, start_line, end_line))
  end
end

-- Add cursor below current position
function M.add_cursor_down()
  local pos = vim.api.nvim_win_get_cursor(0)
  local total_lines = vim.api.nvim_buf_line_count(0)
  
  if pos[1] < total_lines then
    local new_pos = {pos[1] + 1, pos[2]}
    table.insert(M.cursors, new_pos)
    vim.api.nvim_win_set_cursor(0, new_pos)
    M.active = true
    draw_cursors()
    print(string.format("Cursors: %d", #M.cursors))
  else
    print("Already at last line")
  end
end

-- Add cursor above current position
function M.add_cursor_up()
  local pos = vim.api.nvim_win_get_cursor(0)
  
  if pos[1] > 1 then
    local new_pos = {pos[1] - 1, pos[2]}
    table.insert(M.cursors, new_pos)
    vim.api.nvim_win_set_cursor(0, new_pos)
    M.active = true
    draw_cursors()
    print(string.format("Cursors: %d", #M.cursors))
  else
    print("Already at first line")
  end
end

-- Execute action at all cursor positions
local function execute_at_cursors(action)
  if not M.active or #M.cursors == 0 then
    return false
  end
  
  -- Sort cursors by position (bottom to top to avoid offset issues)
  table.sort(M.cursors, function(a, b)
    if a[1] == b[1] then return a[2] > b[2] end
    return a[1] > b[1]
  end)
  
  local saved_view = vim.fn.winsaveview()
  
  for _, pos in ipairs(M.cursors) do
    vim.api.nvim_win_set_cursor(0, pos)
    action()
  end
  
  vim.fn.winrestview(saved_view)
  
  -- Update cursor positions after action
  draw_cursors()
  return true
end

-- Insert text at all cursors
function M.insert_mode()
  if not M.active then
    vim.api.nvim_feedkeys('i', 'n', false)
    return
  end
  
  local text = vim.fn.input("Insert: ")
  if text == '' then return end
  
  execute_at_cursors(function()
    local pos = vim.api.nvim_win_get_cursor(0)
    local line = vim.api.nvim_buf_get_lines(0, pos[1] - 1, pos[1], false)[1]
    local new_line = line:sub(1, pos[2]) .. text .. line:sub(pos[2] + 1)
    vim.api.nvim_buf_set_lines(0, pos[1] - 1, pos[1], false, {new_line})
    
    -- Update cursor position
    for i, c in ipairs(M.cursors) do
      if c[1] == pos[1] and c[2] == pos[2] then
        M.cursors[i] = {pos[1], pos[2] + #text}
        break
      end
    end
  end)
  
  draw_cursors()
end

-- Append text at all cursors
function M.append_mode()
  if not M.active then
    vim.api.nvim_feedkeys('a', 'n', false)
    return
  end
  
  -- Move all cursors one position right first
  for i, pos in ipairs(M.cursors) do
    M.cursors[i] = {pos[1], pos[2] + 1}
  end
  
  M.insert_mode()
end

-- Delete character at all cursors
function M.delete_char()
  if not execute_at_cursors(function()
    vim.cmd('normal! x')
  end) then
    vim.cmd('normal! x')
  end
end

-- Change word at all cursors
function M.change_word()
  if not M.active then
    vim.api.nvim_feedkeys('cw', 'n', false)
    return
  end
  
  local text = vim.fn.input("Change to: ")
  if text == '' then return end
  
  execute_at_cursors(function()
    vim.cmd('normal! ciw' .. text)
  end)
  
  clear_cursors()
end


function M.delete_word()
  local ok = execute_at_cursors(function()
    vim.cmd('normal! diw')
  end)

  if not ok then
    vim.cmd('normal! diw')
  end

  if M.active then
    vim.defer_fn(function() draw_cursors() end, 10)
  end
end


-- Undo last cursor
function M.undo_cursor()
  if #M.cursors > 0 then
    table.remove(M.cursors)
    draw_cursors()
    print(string.format("Cursors: %d", #M.cursors))
    if #M.cursors == 0 then
      M.active = false
    end
  end
end

-- Setup keymaps
function M.setup()
  local opts = { noremap = true, silent = true }
  
  -- Core multi-cursor operations
  vim.keymap.set('n', '<C-n>', M.select_next_word, vim.tbl_extend('force', opts, {desc = 'Select next word occurrence'}))
  vim.keymap.set('n', '<C-S-n>', M.skip_next_word, vim.tbl_extend('force', opts, {desc = 'Skip and select next occurrence'}))
  vim.keymap.set('n', '<leader><C-n>', M.select_all_word, vim.tbl_extend('force', opts, {desc = 'Select all word occurrences'}))
  
  -- NEW: Add cursor at word under cursor
  vim.keymap.set('n', '<leader>mw', M.add_cursor_at_word, vim.tbl_extend('force', opts, {desc = 'Add cursor at word'}))
  
  -- Manual cursor placement (works independently now)
  vim.keymap.set('n', '<C-Down>', M.add_cursor_down, vim.tbl_extend('force', opts, {desc = 'Add cursor below'}))
  vim.keymap.set('n', '<C-Up>', M.add_cursor_up, vim.tbl_extend('force', opts, {desc = 'Add cursor above'}))
  
  -- Visual mode: add cursor to each line (FIXED)
  vim.keymap.set('v', '<C-n>', M.add_cursors_to_selection, vim.tbl_extend('force', opts, {desc = 'Add cursor to each line'}))
  
  -- Multi-cursor editing
  vim.keymap.set('n', '<leader>mi', M.insert_mode, vim.tbl_extend('force', opts, {desc = 'Multi-cursor insert'}))
  vim.keymap.set('n', '<leader>ma', M.append_mode, vim.tbl_extend('force', opts, {desc = 'Multi-cursor append'}))
  vim.keymap.set('n', '<leader>mx', M.delete_char, vim.tbl_extend('force', opts, {desc = 'Multi-cursor delete char'}))
  vim.keymap.set('n', '<leader>mc', M.change_word, vim.tbl_extend('force', opts, {desc = 'Multi-cursor change word'}))
  vim.keymap.set('n', '<leader>md', M.delete_word, vim.tbl_extend('force', opts, {desc = 'Multi-cursor delete word'}))
  
  -- Clear and undo
  vim.keymap.set('n', '<Esc>', function()
    if M.active then
      clear_cursors()
      print("Cleared cursors")
    else
      vim.api.nvim_feedkeys(vim.api.nvim_replace_termcodes('<Esc>', true, false, true), 'n', false)
    end
  end, opts)
  vim.keymap.set('n', '<leader>mu', M.undo_cursor, vim.tbl_extend('force', opts, {desc = 'Undo last cursor'}))
  
  -- Create commands
  vim.api.nvim_create_user_command('MClear', clear_cursors, {})
  vim.api.nvim_create_user_command('MSelectAll', M.select_all_word, {})
  
  print("Multi-cursor setup complete!")
end

-- Auto-setup
M.setup()

return M
