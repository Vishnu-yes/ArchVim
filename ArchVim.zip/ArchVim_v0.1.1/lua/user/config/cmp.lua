-- cmp.lua
local cmp = require("cmp")
local luasnip = require("luasnip")
local cmp_autopairs = require('nvim-autopairs.completion.cmp')
local lspkind = require("lspkind")

-- Flag to toggle docs
_G.cmp_doc_enabled = false

-- Function to toggle docs
function _G.toggle_cmp_docs()
    _G.cmp_doc_enabled = not _G.cmp_doc_enabled

    cmp.setup {
        window = {
            completion = cmp.config.window.bordered({
                winhighlight = "Normal:NormalFloat,FloatBorder:FloatBorder,CursorLine:PmenuSel,Search:None",
                col_offset = -3,
                side_padding = 0,
            }),
            documentation = _G.cmp_doc_enabled and cmp.config.window.bordered() or nil,
        }
    }

    print("CMP Docs:", _G.cmp_doc_enabled)
end

-- Attach autopairs to confirm completion
cmp.event:on('confirm_done', cmp_autopairs.on_confirm_done())

-- Main cmp setup
cmp.setup({
    snippet = {
        expand = function(args)
            luasnip.lsp_expand(args.body)
        end,
    },

    mapping = cmp.mapping.preset.insert({
        ["<C-b>"] = cmp.mapping.scroll_docs(-4),
        ["<C-f>"] = cmp.mapping.scroll_docs(4),
        ["<C-Space>"] = cmp.mapping.complete(),
        ["<C-e>"] = cmp.mapping.abort(),
        ["<CR>"] = cmp.mapping(function(fallback)
            if cmp.visible() and cmp.get_selected_entry() then
                cmp.confirm({ select = false }) -- only confirm explicitly selected
            else
                fallback()
            end
        end, { "i", "s" }),

        ["<Tab>"] = cmp.mapping(function(fallback)
            if cmp.visible() then
                cmp.select_next_item({ behavior = cmp.SelectBehavior.Insert })
            elseif luasnip.expand_or_jumpable() then
                luasnip.expand_or_jump()
            else
                fallback()
            end
        end, { "i", "s" }),

        ["<S-Tab>"] = cmp.mapping(function(fallback)
            if cmp.visible() then
                cmp.select_prev_item({ behavior = cmp.SelectBehavior.Insert })
            elseif luasnip.jumpable(-1) then
                luasnip.jump(-1)
            else
                fallback()
            end
        end, { "i", "s" }),
    }),

    sources = cmp.config.sources({
        { name = "nvim_lsp" },
        { name = "luasnip" },
        { name = "buffer" },
        { name = "path" },
    }),

    completion = {
        completeopt = "menu,menuone,noselect",
    },

    experimental = {
        ghost_text = true,
    },

    enabled = function()
        local line = vim.api.nvim_get_current_line()
        local col = vim.api.nvim_win_get_cursor(0)[2]
        return col <= #line
    end,

    formatting = {
        format = lspkind.cmp_format({
            mode = "symbol_text",
            maxwidth = 30,   -- small width like Godot
            ellipsis_char = '…',
        })
    },

    window = {
        completion = cmp.config.window.bordered({
            winhighlight = "Normal:NormalFloat,FloatBorder:FloatBorder,CursorLine:PmenuSel,Search:None",
            col_offset = -3,
            side_padding = 0,
        }),
        documentation = nil,
    },
})

-- Reduce popup height
vim.opt.pumheight = 6

-- Highlight groups
vim.cmd([[
highlight! CmpItemAbbr guifg=#ebdbb2
highlight! CmpItemAbbrMatch guifg=#fabd2f
highlight! CmpItemKind guifg=#8ec07c
highlight! CmpItemMenu guifg=#928374
]])

-- Map local leader + c to toggle cmp docs
vim.api.nvim_set_keymap(
    'n',
    '<localleader>c',
    [[:lua _G.toggle_cmp_docs()<CR>]],
    { noremap = true, silent = true }
)
