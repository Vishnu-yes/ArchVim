return {
    "folke/which-key.nvim",
    event = "VeryLazy",
    config = function()
        local wk = require("which-key")

        -- Setup
        wk.setup({
            plugins = {
                marks = true,     -- shows your marks
                registers = true, -- shows registers on " in NORMAL or <C-r> in INSERT
                spelling = { enabled = true, suggestions = 20 },
            },
            window = {
                border = "double", -- nice double border
                position = "bottom",
                margin = { 0, 0, 0, 0 },
                padding = { 0, 0, 0, 0 },
                winblend = 5, -- slightly transparent
            },
            layout = {
                height = { min = 30, max = 60 },
                width = { min = 5, max = 10 },
                spacing = 3,
                align = "left",
            },
            icons = {
                breadcrumb = "»",
                separator = "➜",
                group = "+",
            },
            show_help = true,
            show_keys = true,
        })

        -- TokyoNight inspired colors
        local colors = {
            bg        = "#ff8605",
            fg        = "#c0caf5",
            key       = "#7aa2f7",
            group     = "#bb9af7",
            border    = "#ffffff",
            separator = "#000000",
        }

        vim.api.nvim_set_hl(0, "WhichKey", { fg = colors.key, bg = colors.bg })
        vim.api.nvim_set_hl(0, "WhichKeyGroup", { fg = colors.group, bg = colors.bg, bold = true })
        vim.api.nvim_set_hl(0, "WhichKeyDesc", { fg = colors.fg, bg = colors.bg })
        vim.api.nvim_set_hl(0, "WhichKeyBorder", { fg = colors.border, bg = colors.bg })
        vim.api.nvim_set_hl(0, "WhichKeyFloat", { bg = colors.bg })
        vim.api.nvim_set_hl(0, "WhichKeySeparator", { fg = colors.separator, bg = colors.bg })

        -- Leader key mappings
        wk.register({
            f = {
                name = "Find",
                f = { "<cmd>Telescope find_files<cr>", "Files" },
                g = { "<cmd>Telescope live_grep<cr>", "Grep" },
                b = { "<cmd>Telescope buffers<cr>", "Buffers" },
                h = { "<cmd>Telescope help_tags<cr>", "Help" },
            },
            c = {
                name = "Config",
                r = {
                    function()
                        dofile(vim.fn.stdpath("config") .. "/init.lua")
                        vim.notify("Config reloaded!", vim.log.levels.INFO)
                    end,
                    "Reload config",
                },
            },
            w = { "<cmd>w<cr>", "Save file" },
        }, { prefix = "<leader>" })
    end,
}
