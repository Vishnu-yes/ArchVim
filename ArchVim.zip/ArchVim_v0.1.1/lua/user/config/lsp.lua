-- =====================================================
-- Chad Coder LSP Giant ⚡ (Future-Proof, Nvim 0.12+)
-- =====================================================
-- Pure vim.lsp.config + vim.lsp.enable (no lspconfig)
-- =====================================================

-- 1. on_attach: keymaps
local function on_attach(_, bufnr)
  local opts = { noremap = true, silent = true, buffer = bufnr }
  local map = vim.keymap.set
  map("n", "gd", vim.lsp.buf.definition, opts)
  map("n", "K", vim.lsp.buf.hover, opts)
  map("n", "gr", vim.lsp.buf.references, opts)
  map("n", "<leader>rn", vim.lsp.buf.rename, opts)
  map("n", "<leader>ca", vim.lsp.buf.code_action, opts)
  map("n", "<leader>f", function() vim.lsp.buf.format { async = true } end, opts)
end

-- 2. Capabilities (works with cmp-nvim-lsp)
local capabilities = vim.lsp.protocol.make_client_capabilities()
pcall(function()
  capabilities = require("cmp_nvim_lsp").default_capabilities(capabilities)
end)

-- 3. Default config
local default_config = {
  on_attach = on_attach,
  capabilities = capabilities,
}

-- 4. Servers
local servers = {
  -- Core
  bashls       = { cmd = { "bash-language-server", "start" }, filetypes = { "sh", "bash" } },
  jsonls       = { cmd = { "vscode-json-language-server", "--stdio" }, filetypes = { "json" } },
  yamlls       = { cmd = { "yaml-language-server", "--stdio" }, filetypes = { "yaml", "yml" } },
  dockerls     = { cmd = { "docker-langserver", "--stdio" }, filetypes = { "dockerfile" } },
  marksman     = { cmd = { "marksman", "server" }, filetypes = { "markdown" } },

  -- Web
  html         = { cmd = { "vscode-html-language-server", "--stdio" }, filetypes = { "html" } },
  cssls        = { cmd = { "vscode-css-language-server", "--stdio" }, filetypes = { "css", "scss", "less" } },
  tsserver     = { cmd = { "typescript-language-server", "--stdio" }, filetypes = { "javascript", "typescript" } },
  eslint       = { cmd = { "vscode-eslint-language-server", "--stdio" }, filetypes = { "javascript", "typescript" } },

  -- System
  clangd       = { cmd = { "clangd", "--background-index" }, filetypes = { "c", "cpp" } },
  asm_lsp      = { cmd = { "asm-lsp" }, filetypes = { "asm", "s" } },
  cmake        = { cmd = { "cmake-language-server" }, filetypes = { "cmake" } },
  vimls        = { cmd = { "vim-language-server", "--stdio" }, filetypes = { "vim" } },

  -- Scripting
  pyright      = { cmd = { "pyright-langserver", "--stdio" }, filetypes = { "python" } },
  lua_ls       = {
    cmd = { "lua-language-server" },
    filetypes = { "lua" },
    settings = {
      Lua = {
        runtime = { version = "Lua 5.4" },
        diagnostics = { globals = { "vim" } },
        workspace = {
          checkThirdParty = false,
          library = vim.api.nvim_get_runtime_file("", true),
        },
        telemetry = { enable = false },
      },
    },
  },

  -- Extra Chad Power
  rust_analyzer = { cmd = { "rust-analyzer" }, filetypes = { "rust" } },
  gopls         = { cmd = { "gopls" }, filetypes = { "go" } },
  phpactor      = { cmd = { "phpactor", "language-server" }, filetypes = { "php" } },
}

-- 5. Setup all
for server, opts in pairs(servers) do
  vim.lsp.config(server, vim.tbl_deep_extend("force", default_config, opts))
end
vim.keymap.set("n", "<leader>la", vim.diagnostic.open_float, { desc = "Show Diagnostics" })

-- 6. Enable all 🎉
vim.lsp.enable(vim.tbl_keys(servers))
