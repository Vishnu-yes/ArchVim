-- =====================
-- 17) Sessions & Workspaces
-- =====================
require("auto-session").setup({
    log_level = "error",
    auto_session_enable_last_session = false,
    auto_session_enabled = true,
    auto_save_enabled = true,
    auto_restore_enabled = true,
    auto_session_suppress_dirs = { "~/", "/", "/tmp" },
    auto_session_root_dir = vim.fn.stdpath("data") .. "/sessions/", -- keep sessions in one place
    -- Optional: hook for pre-save cleanup
    pre_save_cmds = { "NvimTreeClose", "cclose" },
})

-- Workspaces integration (optional, if using workspaces.nvim)
require("workspaces").setup({
    hooks = {
        open = { "SessionRestore" },
        add = { "SessionSave" },
    },
})

-- Keymaps
local map = vim.keymap.set
local opts = { noremap = true, silent = true }

-- Project/Workspace related
map("n", "<leader>pw", ":WorkspacesOpen<CR>", { desc = "Open Workspaces" })
map("n", "<leader>pa", ":WorkspacesAdd<CR>",  { desc = "Add Current Dir as Workspace" })
map("n", "<leader>pr", ":WorkspacesRemove<CR>", { desc = "Remove Workspace" })

-- Session management
map("n", "<leader>ps", ":SessionSave<CR>",   { desc = "Save Session" })
map("n", "<leader>pl", ":SessionRestore<CR>", { desc = "Load Last Session" })
map("n", "<leader>pd", ":SessionDelete<CR>", { desc = "Delete Session" })
