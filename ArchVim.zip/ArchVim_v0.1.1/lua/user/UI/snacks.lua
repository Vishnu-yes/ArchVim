-- ~/.config/nvim/lua/user/UI/ui.lua
return {
  {
    "folke/snacks.nvim",
    event = "VeryLazy",
    opts = {
      -- 🔹 Enable core modules
      input  = { enabled = true },
      select = { enabled = true },
      notify = {
        enabled  = true,
        timeout  = 4000,
        top_down = false,
        style    = "compact",
      },
      progress = {
        enabled = true,
        spinner = "dots",
        refresh = 50,
      },
      picker = {
        enabled = true,
        layout  = "vertical",
        border  = "rounded",
      },

      -- 🔸 Disabled as overridden elsewhere
      statuscolumn = { enabled = false },

      -- =========================
      -- Modern Fancy Snacks Highlights
      -- =========================
      highlight = {
        -- Notifiers
        SnacksNotifierBorder = { fg = "#FABD2F", bg = "#1E1E2E", bold = true },
        SnacksNotifierTitle  = { fg = "#83A598", bold = true },
        SnacksNotifierIcon   = { fg = "#D79921" },
        SnacksNotifierMsg    = { fg = "#EBDBB2", bg = "#1E1E2E" },

        -- Input / prompts
        SnacksInputBorder    = { fg = "#458588", bg = "#1E1E2E", bold = true },
        SnacksPickerBorder   = { fg = "#B16286", bg = "#1E1E2E", bold = true },
        SnacksPickerCounter  = { fg = "#FFFFFF", bg = "#3C3836", bold = true },
        SnacksPickerTitle    = { fg = "#83A598", bold = true },

        -- Progress bars / status
        SnacksProgressBorder = { fg = "#98971A", bg = "#1E1E2E", bold = true },
        SnacksProgressBar    = { fg = "#B8BB26", bg = "#3C3836", bold = true },
        SnacksProgressMsg    = { fg = "#EBDBB2", bg = "#3C3836" },

        -- Icons & accents
        SnacksNotifierAccent = { fg = "#FB4934", bold = true },
        SnacksPickerAccent   = { fg = "#FABD2F", bold = true },
      },
    },

    config = function(_, _)
      local notifier = require("snacks.notifier")
      -- Force Snacks to replace vim.notify
      vim.notify = notifier.notify
    end,
    -- 🔹 Practical keymaps
keys = {
  { "<leader>nn", function() require("snacks.notifier").history() end, desc = "Snacks Notifications History" },
  { "<leader>np", function() require("snacks.progress").show() end, desc = "Snacks Progress (LSP/Tasks)" },
  { "<leader>ni", function() require("snacks.input").open() end, desc = "Snacks Input Prompt" },
  { "<leader>nb", function() require("snacks.picker").buffers() end, desc = "Snacks Buffer Picker" },
},
    -- Keep your existing UI modules
  { import = "user.UI.bufferline" },
  { import = "user.UI.statusline" },
  { import = "user.UI.gitsigns" },
  { import = "user.UI.diagnosticsigns" },
  { import = "user.UI.dashboard" },
  { import = "user.UI.DAP_UI" },
  { import = "user.UI.IBL" },
}
}
