-- Alpha.nvim configuration
local status_ok, alpha = pcall(require, "alpha")
if not status_ok then
  return
end

local dashboard = require("alpha.themes.dashboard")

-- =========================
-- Header (ASCII Art + Branding)
-- =========================
dashboard.section.header.val = {
"       █████████                      █████      █████   █████  ███                   ",
"      ███░░░░░███                    ░░███      ░░███   ░░███  ░░░                    ",
"     ░███    ░███  ████████   ██████  ░███████   ░███    ░███  ████  █████████████    ",
"     ░███████████ ░░███░░███ ███░░███ ░███░░███  ░███    ░███ ░░███ ░░███░░███░░███   ",
"     ░███░░░░░███  ░███ ░░░ ░███ ░░░  ░███ ░███  ░░███   ███   ░███  ░███ ░███ ░███   ",
"     ░███    ░███  ░███     ░███  ███ ░███ ░███   ░░░█████░    ░███  ░███ ░███ ░███   ",
"     █████   █████ █████    ░░██████  ████ █████    ░░███      █████ █████░███ █████  ",
"    ░░░░░   ░░░░░ ░░░░░      ░░░░░░  ░░░░ ░░░░░      ░░░      ░░░░░ ░░░░░ ░░░ ░░░░░   ",
"                                                                                      ",
"                                                                                      ",
"                                                                                      ",

}


-- =========================
-- Center (Buttons / Actions)
-- =========================
dashboard.section.buttons.val = {
  dashboard.button("f", "   Find File", ":Telescope find_files<CR>"),
  dashboard.button("r", "   Recent Files", ":Telescope oldfiles<CR>"),
  dashboard.button("e", "   File Explorer", ":NvimTreeToggle<CR>"),
  dashboard.button("w", "󱎰   Find Word", ":Telescope live_grep<CR>"),
  dashboard.button("c", "   Config", ":e $MYVIMRC<CR>"),
  dashboard.button("s", "󰅟   Restore Session", ":SessionLoad<CR>"),
  dashboard.button("q", "󰈆   Quit", ":qa<CR>"),
}

-- =========================
-- Footer (Tips + Load Time)
-- =========================
local tips = {
  " Tip: Press `SPC f f` to quickly find a file",
  " Tip: Use `:qa` to quit Neovim instantly",
  "󰒲 Tip: Try `SPC g g` for live grep search",
  "󰍉 Tip: Edit config with `SPC c`",
}
math.randomseed(os.time())
local footer_tip = tips[math.random(#tips)]

local stats = "⚡ Neovim loaded in "
  .. string.format("%.3f", vim.fn.reltimefloat(vim.fn.reltime(vim.g.start_time)))
  .. "s"

dashboard.section.footer.val = { footer_tip, stats }

-- =========================
-- Highlighting (Gruvbox Dark Hard)
-- =========================
-- Gruvbox Dark Hard core colors
local colors = {
  bg       = "#1d2021", -- dark0_hard
  blue     = "#83a598", -- bright_blue
  yellow   = "#fabd2f", -- bright_yellow
  green    = "#b8bb26", -- bright_green
  gray     = "#928374", -- gray
  fg       = "#ebdbb2", -- fg1
}

-- Apply highlights (Lua API for consistency)
vim.api.nvim_set_hl(0, "DashboardHeader", { fg = colors.blue, bg = colors.bg, bold = true })
vim.api.nvim_set_hl(0, "DashboardCenter", { fg = colors.fg, bg = colors.bg })
vim.api.nvim_set_hl(0, "DashboardFooter", { fg = colors.green, bg = colors.bg, italic = true })
vim.api.nvim_set_hl(0, "DashboardLine",   { fg = colors.gray, bg = colors.bg })

-- Ensure dashboard background matches editor
vim.api.nvim_set_hl(0, "Normal", { bg = colors.bg, fg = colors.fg })

-- =========================
-- Line Highlighting Effect
-- =========================
-- Add a subtle "line separator" under each section
dashboard.config.layout = {
  { type = "padding", val = 2 },
  dashboard.section.header,
  { type = "padding", val = 1 },
  { type = "text", val = string.rep("─", 50), opts = { hl = "DashboardLine", position = "center" } },
  { type = "padding", val = 1 },
  dashboard.section.buttons,
  { type = "padding", val = 1 },
  { type = "text", val = string.rep("─", 50), opts = { hl = "DashboardLine", position = "center" } },
  { type = "padding", val = 1 },
  dashboard.section.footer,
}

-- =========================
-- Apply Dashboard
-- =========================
alpha.setup(dashboard.opts)
